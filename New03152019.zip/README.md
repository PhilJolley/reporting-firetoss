<h1>This was my First WordPress Site</h1>
<p>When I first started at firetoss as an intern,
there was a need for an analytics platform that clients
could go to and easily see their analytics. 

I didn't know what I was doing, because I had never built
anything in WordPress. I also had never work with the theme
built from the Firetoss team. I did my best with the knowledge I
had and am now just maintaining it.
</p>